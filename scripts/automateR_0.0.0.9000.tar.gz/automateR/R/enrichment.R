run_gsea <- function(category) {
    # Load in desired gene set with msigdbr
    gene.set <- msigdbr(species = "Homo sapiens", category = category) %>%
        dplyr::select(gs_name, entrez_gene)
    
    
    

}
