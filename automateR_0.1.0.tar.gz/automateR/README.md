
# automateR

<!-- badges: start -->
<!-- badges: end -->

The goal of automateR is to ...

## Installation

You can install the development version of automateR from [GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("SauravK182/cancer_thesis")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(automateR)
## basic example code
```

